const summaryList = document.querySelector(".summary-list");

data.forEach((item) => {
  const listItem = document.createElement("li");
  listItem.classList.add("summary-item");
  listItem.style.backgroundColor = `${item.color}10`; // إضافة لون خلفية مع شفافية
  listItem.innerHTML = `
    <div class="label">
      <img src="${item.icon}" class="icon" alt="${item.category} icon">
      ${item.category}
    </div>
    <span class="value">${item.score} / 100</span>
  `;
  summaryList.appendChild(listItem);
});

document.querySelector(".continue-btn").addEventListener("click", () => {
  alert("Continue button clicked!");
});